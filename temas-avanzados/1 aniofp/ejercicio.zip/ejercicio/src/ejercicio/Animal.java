/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio;

/**
 *
 * @author Medac
 */
public class Animal {
    String Tipoanimal;
    double peso;
    int numero_patas;
    String base_alimentacion;
    
    public Animal(String Tipoanimal,double peso, int numero_patas, String base_alimentacion){
        this.Tipoanimal=Tipoanimal;
        this.peso=peso;
        this.numero_patas=numero_patas;
        this.base_alimentacion=base_alimentacion;
    }
    public void mostrar(){
        System.out.println("Tipo de animal "+Tipoanimal+" Peso "+peso+" base de alimentacion "+base_alimentacion);
    }
   int devolver_numero_patas(){
       return numero_patas;
   }
        
    }

