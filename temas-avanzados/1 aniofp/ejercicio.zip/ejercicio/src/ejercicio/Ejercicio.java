/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio;

/**
 *
 * @author Medac
 */
public class Ejercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Animal gato=new Animal("Gato",5.0,4,"omnivoro");
        Animal mono=new Animal("mono",30.0,4,"omnivoro");
          Animal pato=new Animal("Pato",3.0,2,"herbivoro");
Animal serpiente=new Animal("Serpiente",3.0,0,"carnivoro");


 gato.mostrar();
mono.mostrar();
pato.mostrar();
serpiente.mostrar();

serpiente.Tipoanimal="Topo";

    }
   
    }

