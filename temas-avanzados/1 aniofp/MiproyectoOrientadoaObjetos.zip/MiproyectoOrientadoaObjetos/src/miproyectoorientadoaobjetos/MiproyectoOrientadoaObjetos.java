/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package miproyectoorientadoaobjetos;

/**
 *
 * @author Medac
 */
public class MiproyectoOrientadoaObjetos {

    
    public static void main(String[] args) {
      Persona p1=new Persona();
      Persona p2=new Persona("Antonio","Flores",777,26,'v',1.75,76.5);
      Persona p3=new Persona();
        System.out.println(p1==p3);
        Persona p4=new Persona("Antonio","Flores",777,26,'v',1.75,76.5);
        System.out.println(p2==p4); //no son iguales ya que tienen direcciones de memoria distintas, "new"
        
        
        p1.mostrar();
        p2.mostrar();
        System.out.println(p2.nombre);
        System.out.println(p2.apellidos);
        System.out.println(p2.edad);
        p2.comer();
        
        
        
    }
    
}
