/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package miproyectoorientadoaobjetos;

/**
 *
 * @author Medac
 */
public class Persona {
    //atributos
    String nombre;
    String apellidos;
    int dni;
    int edad;
    char sexo;
    double altura;
    double peso;
    
    
    //constructor vacio
    public Persona(){
        nombre="sin nombre";
        apellidos="sin apellidos";
        sexo='n';
    }
    
    //constructor con parametors
    public Persona(String nombre, String appelidos, int dni, int edad, char sexo, double altura, double peso){
        this.nombre=nombre;
                this.apellidos=apellidos;
                this.dni=dni;
                        this.edad=edad;
                        this.sexo=sexo;
                        this.altura=altura;
                        this.peso=peso;
                        
    }
                        //metodos
    public void mostrar (){
                            System.out.println("nombre"+nombre+"apellidos"+apellidos+"dni"+dni+"edad"+edad+"sexo"+sexo+"altura"+altura+"peso"+peso);
                        }
    public void comer(){
        System.out.println("comiendo...");
    }
    }
    

