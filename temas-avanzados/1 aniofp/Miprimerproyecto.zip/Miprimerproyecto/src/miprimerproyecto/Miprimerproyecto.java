/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package miprimerproyecto;

/**
 *
 * @author Medac
 */
public class Miprimerproyecto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //System.out.println("h");
       int numero=5, numero2=12, numero3=25;
       System.out.println("La suma de los numeros es:"+(numero+numero2+numero3));
        System.out.println("El producto de los numeros es:"+(numero*numero2*numero3));
    }
    
}
