/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciostring;

import java.util.Scanner;


public class EjercicioString {

    public static void main(String[] args) {
        
        
  /*   String palabra= "Hola ";   
        System.out.println(palabra);
    
        //longitud de la palabra
        System.out.println(palabra.length());
        String palabra2="como estas";
 String palabra3=palabra+palabra2;
        System.out.println(palabra3);*/
  
//equals
 /* String palabra="Hola";
  String palabra2= "hola";
        System.out.println(palabra.equals(palabra2));//compara si son iguales
        System.out.println(palabra.equalsIgnoreCase(palabra2)); //ignora las mayusculas, compara si son iguales independientemente de si son mayusculas*/
     
 //compare
   /*     String palabra="Alvaro";
        String palabra2="Zoe";
        System.out.println(palabra.compareTo(palabra2)); //mira alfabeticamente, si es 0 son iguales, si es positivo es menos A>Z, y si es positivo al reves
      
        //charAt
        System.out.println(palabra.charAt(2));//te devuelve el caracter en la posicion establecida, este caso posicion 2*/
  // String palabra="Hola esta clase es muy chula";
       // System.out.println(palabra.substring(5));//Esto hace que empiece a partir de una posicion, es una sub cadena y si pones (5,9) das un incio y fin, es como un corte
      
//trim
     //  String palabra2="           hola";
      //  System.out.println(palabra2.trim()); //quita espacios en blanco
        
        //indexOf
    /*    System.out.println(palabra.indexOf("la")); //dice donde esta "la", la posicion (vale palabra, caracter) solo da la primera
        */
        //isEmpty
   /*   String  palabra2="";
        System.out.println(palabra2.isEmpty()); //te dice si esta vacio, si esta vacio te da true, sino false, el espacio hace que sea true
        */
        //Contains
       /* String palabra3="oye, eres un tio muy cabron";
        System.out.println(palabra3.contains("cabron")); //revisa si tiene esa palabra*/
       
       //toUpper/LowerCase()
  /*      System.out.println(palabra.toUpperCase());//toda la cadena la convierte en mayuscula
          System.out.println(palabra.toLowerCase());//toda la cadena la convierte en minuscula*/
  
  //replace
 /* String palabra2="Hijo de Puta";
        System.out.println(palabra2.replace('H','f'));//para reemplazar  la H por f en todo el String cadena, el mayuscula o minuscula importa
System.out.println(palabra2.replace('P','m'));*/
 
 //char[] array
 /*char [] array=palabra.toCharArray(); //convierte el String en char
                */
 
 //String.valueOf
 /*
 int numero=7424;
 String palabra_numero= String.valueOf(numero);//convierte el int,double a String
        System.out.println(palabra_numero);*/
 
 
 
 
 
 
 //Ejercicios
 
 //Ejercicio 1, comparamos el tamaño de dos palabras
 Scanner sc=new Scanner (System.in);
 /*       System.out.println("Introduce dos palabras");
        
        System.out.println(" ");
        System.out.println("La primera");
    String  palabra1=sc.next();
        System.out.println(" ");
        System.out.println("Ahora la segunda");
        String  palabra2=sc.next();
       
 if (palabra1.length()>palabra2.length()){
     System.out.println("La palabra 1 "+palabra1+" es mayor que palabra2 "+palabra2);
 }
 else{
     System.out.println("La palabra 2 "+palabra2+" es mayor que palabra1 "+palabra1);
 }*/
 
 
 //Ejercicio2, adivina la contraseña
 
     /*   System.out.println("Introduce una contraseña");
        String contraseña=sc.next();
        System.out.println(" ");
        System.out.println("Vamos a darte una pista");
        System.out.println("empieza por la letra "+contraseña.charAt(0));
        System.out.println(" ");
        System.out.println("Cual es la contraseña");
        String adivina=sc.next();
        while (!adivina.equals(contraseña)){
            System.out.println("Introduce la palabra");
        adivina=sc.next();
        }*/
        
     //ejercicio3
    /*    System.out.println("Introduce palabras y las unire hasta que pongas fin");
        String palabra=sc.next();
        String fini="Fin";
        String palabra3=palabra;
     while(!palabra.equalsIgnoreCase(fini)){
         palabra=sc.next();
        
       palabra3=palabra3+palabra+ " ";
       
     }*/
    
    
    //Ejercicio4
     String palabra=sc.next();
    char [] array=palabra.toCharArray();
    int cuenta=0;
    for (int i=0;i<array.length;i++){
        if(array[i]==' '){
            cuenta++;
        }
        else{
            
        }
    }
        System.out.println("Hay "+cuenta+ " espacios en blanco");
        
     
     
        }}
    

