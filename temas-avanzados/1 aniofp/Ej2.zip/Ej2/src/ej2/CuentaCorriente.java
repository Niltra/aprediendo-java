/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ej2;

import java.util.Scanner;

/**
 *
 * @author Medac
 */
public class CuentaCorriente {
     
        //operaciones
        
        //crear la cuenta
        //se necesita nombre y dni
        //inicialmente el saldo es 0, y el limite descubierto=-50
        //Sacar dinero
        //el metodo debe indicar si puedes realizar la operacion
        //ingresar dinero, se incrementa el saldo y muestra la informacion
    
    int saldo;
    int limite_descubierto;
    String nombre;
    int dni;
     
    public CuentaCorriente( int saldo,int limite_descubierto,String nombre,int dni){
    this.saldo=saldo;
    this.limite_descubierto=limite_descubierto;
    this.nombre=nombre;
    this.dni=dni;
}
    void mostrar(){
        System.out.println("Tu saldo es de "+saldo+" limite descubierto "+limite_descubierto+" nombre "+nombre+" dni "+dni);
    }
    void crearcuenta(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Saldo: "+ saldo==0 + " limite descubierto "+ limite_descubierto==-50 +);
    }
    
    
    
    
    
    
    
    
    
}
