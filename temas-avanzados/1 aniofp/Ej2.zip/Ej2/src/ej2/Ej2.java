/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ej2;

/**
 *
 * @author Medac
 */
public class Ej2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Atributos
        
        //Diseñar la clase cuenta corriente
        //saldo
        //limite_descubierto
        //nombre
        //Dni_titular
        
        //operaciones
        
        //crear la cuenta
        //se necesita nombre y dni
        //inicialmente el saldo es 0, y el limite descubierto=-50
        //Sacar dinero
        //el metodo debe indicar si puedes realizar la operacion
        //ingresar dinero, se incrementa el saldo y muestra la informacion
    }
    
}
