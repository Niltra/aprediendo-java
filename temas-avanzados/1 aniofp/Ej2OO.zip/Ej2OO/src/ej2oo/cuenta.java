/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ej2oo;

import java.util.Scanner;

/**
 *
 * @author Medac
 */
class cuenta {
    Scanner sc= new Scanner (System.in);
    int saldo;
    int limite;
    String nombre;
    int dni;
    
    public cuenta(){
       saldo = 0;
       limite = -50;
       nombre = "Sin nombre";
       dni = 000000;
    }
    public cuenta(int saldo, int limite, String nombre, int dni){
        this.nombre = nombre;
        this.dni = dni;
    }
    public void mostrar(){
        System.out.println("saldo: " + saldo + " limite: " + limite + " nombre: " + nombre + " dni: " + dni);
    }
    public void ingresar(){
        saldo = saldo + sc.nextInt();
    }
   public void retirar(){
       int retiro = sc.nextInt();
       if ((saldo-retiro) < -50) {
           System.out.println("Error, superando limite");
           saldo = saldo - sc.nextInt();
       }else{
           saldo = saldo - retiro;
       }
   }
}


