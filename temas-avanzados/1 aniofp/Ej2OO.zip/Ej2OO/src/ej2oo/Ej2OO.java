/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ej2oo;

/**
 *
 * @author Medac
 */
public class Ej2OO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Diseñar clase cuentacorriente, datos: saldo, limite, nombre, dni
        //Crear cuenta necesita nombre y dni
        //Saldo 0, limite descubierto -50
        //metodo sacar dinero y meter
        cuenta c1 = new cuenta(100, -50, "Adrian", 1234);
        c1.mostrar();
        c1.ingresar();
        c1.mostrar();
        c1.retirar();
        c1.mostrar();
        
    }
    
}
